<?php
include dirname(__DIR__) . '/koneksi.php';
include dirname(__DIR__) . '/auth.php';
requireRole('admin');

$id_buku         = (int)$_POST['id'];
$judul       = mysqli_real_escape_string($koneksi, $_POST['judul']);
$foto_lama  = mysqli_real_escape_string($koneksi, $_POST['foto_lama']);
$penulis = mysqli_real_escape_string($koneksi, $_POST['penulis']);
$kategori     = mysqli_real_escape_string($koneksi, $_POST['kategori']);
$stok     = mysqli_real_escape_string($koneksi, $_POST['stok']);


$foto_baru = $_FILES['foto']['name'];
$tmp       = $_FILES['foto']['tmp_name'];

if ($foto_baru != "") {
    if (file_exists(BASE_PATH . '/uploads/foto_buku/' . $foto_lama)) {
        unlink(BASE_PATH . '/uploads/foto_buku/' . $foto_lama);
    }

    move_uploaded_file($tmp, BASE_PATH . '/uploads/foto_buku/' . $foto_baru);

    $query = "UPDATE databuku SET
              judul='$judul',
            foto='$foto_baru',
              penulis='$penulis',
              kategori='$kategori',
              stok=$stok
              WHERE ='$id_buku'";
} else {
    $query = "UPDATE databuku SET
              judul='$judul',
            foto='$foto_baru',
              penulis='$penulis',
              kategori='$kategori',
              stok=$stok
              WHERE id_buku='$id_buku'";
}

mysqli_query($koneksi, $query);
header("location:tampil.php");