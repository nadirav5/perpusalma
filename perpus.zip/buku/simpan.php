<?php
include dirname(__DIR__) . '/koneksi.php';
include dirname(__DIR__) . '/auth.php';
requireRole('admin');

$judul      = mysqli_real_escape_string($koneksi, $_POST['judul']);
$id_buku  = $_POST['id_buku'] ? (int)$_POST['id_buku'] : 'NULL';
$foto = $_FILES['foto']['name'];
$penulis    = mysqli_real_escape_string($koneksi, $_POST['penulis']);
$kategori    = mysqli_real_escape_string($koneksi, $_POST['kategori']);
$stok    = mysqli_real_escape_string($koneksi, $_POST['stok']);
$tmp  = $_FILES['foto']['tmp_name'];

move_uploaded_file($tmp, BASE_PATH . '/uploads/foto_buku/' . $foto);

// Column order: id, judul, foto, penulis, kategori, stok
$query = "INSERT INTO databuku VALUES (NULL, '$judul', '$id_buku', '$foto', '$penulis', '$kategori', $stok)";
mysqli_query($koneksi, $query);

header("location:tampil.php");