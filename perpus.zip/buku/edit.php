<?php
include dirname(__DIR__) . '/koneksi.php';
include dirname(__DIR__) . '/auth.php';
requireRole('admin');

$judul = 'Edit Data Siswa';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$data = mysqli_query($koneksi, "SELECT * FROM databuku WHERE id=$id");
$buku = mysqli_fetch_assoc($data);

if (!$buku) {
    header("location:tampil.php");
    exit;
}


include dirname(__DIR__) . '/layout/header.php';
?>

<h2>Edit Data Buku</h2>

<form action="update.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $buku['id_buku']; ?>">
    <input type="hidden" name="foto_lama" value="<?= $buku['foto']; ?>">

    <label>Judul:</label><br>
    <input type="text" name="judul" value="<?= htmlspecialchars($buku['judul']); ?>" required><br>

<label>Foto Lama:</label><br>
    <img src="<?= BASE_URL; ?>/uploads/foto_buku/<?= $buku['foto']; ?>" width="100"><br><br>

    <label>Ganti Foto (opsional):</label><br>
    <input type="file" name="foto"><br>

    <label>Penulis:</label>
<input type="text" name="penulis" value="<?= htmlspecialchars($buku['penulis']); ?>" required>
<br>


<br>

    <label>Kategori:</label><br>
    <input type="date" name="kategori" value="<?=$buku['kategori']; ?>" required><br>

    <label>Stok:</label><br>
    <input type="text" name="stok" value="<?= htmlspecialchars($buku['stok']); ?>" required><br>

    <button class="btn" type="submit">Update</button>
    <a class="btn btn-danger" href="tampil.php">Batal</a>
</form>

<?php include dirname(__DIR__) . '/layout/footer.php'; ?>